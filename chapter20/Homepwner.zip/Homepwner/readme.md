# chap19 UITableViewCell 하위 클래스 만들기


