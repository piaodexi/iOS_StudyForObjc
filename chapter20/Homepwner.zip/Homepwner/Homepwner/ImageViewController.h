//
//  ImageViewController.h
//  Homepwner
//
//  Created by deokhee park on 2022/12/14.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController
@property (nonatomic, strong) UIImage *image;
@end

