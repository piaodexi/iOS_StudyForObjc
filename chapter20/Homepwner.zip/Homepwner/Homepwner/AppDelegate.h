//
//  AppDelegate.h
//  Homepwner
//
//  Created by deokhee park on 2022/12/09.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;
@end

